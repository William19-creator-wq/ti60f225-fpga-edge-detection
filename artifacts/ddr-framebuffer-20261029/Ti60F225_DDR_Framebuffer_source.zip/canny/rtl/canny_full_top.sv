// FC01…04：RGB→原R2→真实外存分类→实际cache/queue/HY→8bit私有结果帧。
// done只在各子任务真实排空后公开；完整96bit scope不截断为64bit。
module canny_full_top #(
    // STAGE 0 is the original serial full job. 1 stops after drained class
    // writeback; 2 consumes an already complete, exclusively owned class frame.
    // Constant specialization removes unused engines, not algorithm stages.
    parameter integer unsigned WIDTH=1920,HEIGHT=1080,STAGE=0
)(
    output wire [3:0] debug_state,
    input logic clk,rst,
    input logic cj_valid,output wire cj_ready,input logic [141:0] cj,
    input logic [31:0] class_base,queue_base,result_base,
    input logic in_valid,output wire in_ready,input logic [73:0] in_fp,
    output wire grad_valid,input logic grad_ready,output wire [184:0] grad_payload,
    input logic cancel_valid,input logic [95:0] cancel_scope,output wire source_stop,
    output wire done_valid,input logic done_ready,output wire [95:0] done_scope,
    output logic [1:0] outcome,output logic [31:0] reason,
    output logic [20:0] input_pairs,class_pairs,output logic [21:0] output_pixels,edge_pixels,
    output logic [591:0] r2_status_snapshot,output logic [21:0] discarded_pixels,
    output wire line_req_valid,input logic line_req_ready,output wire line_write,
    output wire [31:0] line_addr,output wire [511:0] line_wdata,
    input logic line_rsp_valid,output wire line_rsp_ready,input logic [511:0] line_rdata,
    input logic line_error,line_drained,output wire quarantined
);
    localparam integer unsigned N=WIDTH*HEIGHT,P=N/2;
    localparam logic [32:0] CLASS_BYTES=33'(((N+255)/256)*64),QUEUE_BYTES=33'(((N+15)/16)*64),RESULT_BYTES=33'(((N+63)/64)*64);
    typedef enum logic [3:0] {IDLE,CFG_CLASS_REQ,CFG_CLASS_WAIT,START_R2,R2_RUN,
        CFG_RESULT_REQ,CFG_RESULT_WAIT,START_HY,HY_RUN,FINAL,DONE} state_t;
    state_t state;
    assign debug_state=state;
    initial if(STAGE>2)$fatal(1,"Invalid Canny stage specialization");
    logic [141:0] active_cj;
    logic [31:0] saved_class_base,saved_queue_base,saved_result_base;
    logic [63:0] next_handle,active_handle;
    logic hy_mode,cancel_sticky,failure_sticky;
    logic r2_started,r2_seen,class_seen,hy_started,hy_seen,edge_seen;
    logic r2_success,class_success;
    logic [31:0] failure_mask;
    wire matching_cancel=cancel_valid && cancel_scope==((state==IDLE)?cj[95:0]:active_cj[95:0]);
    wire cancellation=cancel_sticky || matching_cancel;
    wire private_abort=state!=IDLE && state!=DONE && (cancellation || failure_sticky);
    wire [32:0] class_end={1'b0,class_base}+CLASS_BYTES,queue_end={1'b0,queue_base}+QUEUE_BYTES,result_end={1'b0,result_base}+RESULT_BYTES;
    wire class_queue_disjoint=class_end<={1'b0,queue_base} || queue_end<={1'b0,class_base};
    wire class_result_disjoint=class_end<={1'b0,result_base} || result_end<={1'b0,class_base};
    wire queue_result_disjoint=queue_end<={1'b0,result_base} || result_end<={1'b0,queue_base};
    wire job_legal=cj[106:96]==11'(WIDTH) && cj[117:107]==11'(HEIGHT) && cj[128:118]<=cj[139:129] &&
        class_base[5:0]==0 && queue_base[5:0]==0 && result_base[5:0]==0 &&
        class_end<=33'h100000000 && queue_end<=33'h100000000 && result_end<=33'h100000000 &&
        class_queue_disjoint && class_result_disjoint && queue_result_disjoint;
    logic r2_cj_ready,r2_in_ready,r2_class_valid,r2_class_ready,r2_status_valid;
    logic [124:0] r2_class_payload;logic [591:0] r2_status;
    logic class_cfg_ready,class_cfg_rsp_valid,class_cfg_rsp_error,class_done_valid,class_done_error,class_done_aborted,class_done_drained;
    logic [21:0] class_count;
    wire class_storage_clear,class_storage_write,edge_storage_clear,edge_storage_write;
    wire [511:0] class_storage_next,edge_storage_next,shared_writer_payload;
    // R2_RUN advances only after both R2 and the class writer complete.
    // Class done is drained; hy_mode then gives exclusive storage ownership
    // to the result writer through its drained completion. Cancel/fault never
    // bypasses this fence. There is no extra cycle or smaller DDR allocation.
    packed_frame_storage writer_storage(.clk,.rst(rst||class_storage_clear||edge_storage_clear),
        .write_enable(class_storage_write||edge_storage_write),
        .next_data(hy_mode?edge_storage_next:class_storage_next),.held_data(shared_writer_payload));

    logic edge_cfg_ready,edge_cfg_rsp_valid,edge_cfg_rsp_error,edge_in_ready,edge_done_valid,edge_done_error,edge_done_aborted,edge_done_drained;
    logic [21:0] edge_count;
    logic class_rpc_valid,class_rpc_ready,class_rpc_write,class_rpc_rsp_ready,class_quarantined;
    logic [31:0] class_rpc_addr;logic [511:0] class_rpc_data;
    logic edge_rpc_valid,edge_rpc_ready,edge_rpc_write,edge_rpc_rsp_ready,edge_quarantined;
    logic [31:0] edge_rpc_addr;logic [511:0] edge_rpc_data;
    logic h_job_ready,h_pixel_valid,h_pixel_ready,h_pixel_edge,h_done_valid,h_quarantined;
    localparam integer unsigned EXPORT_LANES=8;
    logic [7:0] h_pixel_edges;
    logic [20:0] h_pixel_index;logic [63:0] h_pixel_id,h_done_id;
    logic [1:0] h_outcome;logic [7:0] h_reason;logic [21:0] h_enqueue,h_pop,h_output;
    logic [1:0] rpc_valid,rpc_ready,rpc_write,rpc_rsp_valid,rpc_rsp_ready;
    logic [31:0] rpc_addr[0:1];logic [511:0] rpc_wdata[0:1],rpc_rdata;
    logic rpc_error,rpc_drained,a_quarantined;
    logic complete_r2;
    wire r2_status_fire=r2_status_valid && r2_started && !r2_seen;
    wire class_done_fire=class_done_valid && !class_seen;
    wire hy_done_fire=h_done_valid && hy_started && !hy_seen;
    wire edge_done_fire=edge_done_valid && !edge_seen;
    wire physical_error=line_rsp_valid && line_rsp_ready && line_error;
    // synthesis translate_off
    always @(posedge clk)if(!rst)begin
        if((class_storage_write||class_storage_clear)&&(edge_storage_write||edge_storage_clear))
            $fatal(1,"Canny writer storage has two owners");
        if((class_storage_write||class_storage_clear)&&hy_mode)
            $fatal(1,"Class writer used result-owned storage");
        if((edge_storage_write||edge_storage_clear)&&!hy_mode)
            $fatal(1,"Result writer used class-owned storage");
        if(STAGE!=2&&state==CFG_RESULT_REQ&&(!class_seen||!class_success||class_rpc_valid))
            $fatal(1,"Writer storage transferred before class drain");
    end
    // synthesis translate_on
    assign cj_ready=!rst && state==IDLE && !quarantined && next_handle!=64'hffffffffffffffff;
    assign done_valid=!rst && state==DONE;
    assign done_scope=active_cj[95:0];
    assign source_stop=!rst && state!=IDLE && (private_abort || r2_seen || hy_mode || state==DONE);
    assign in_ready=!rst && !hy_mode && r2_started && !r2_seen && r2_in_ready;
    assign quarantined=class_quarantined || edge_quarantined || h_quarantined || a_quarantined;
    // v1.1：失败writer已真实done后，给HY旧held pixel明确discard消费出口。
    wire [21:0] h_pixel_step=({1'b0,h_pixel_index}+22'(EXPORT_LANES)>22'(N))
        ?22'(N)-{1'b0,h_pixel_index}:22'(EXPORT_LANES);
    assign h_pixel_ready=edge_in_ready || (private_abort && (edge_seen || edge_done_valid));
    always_comb begin
        rpc_valid[0]=hy_mode ? edge_rpc_valid : class_rpc_valid;
        rpc_write[0]=hy_mode ? edge_rpc_write : class_rpc_write;
        rpc_addr[0]=hy_mode ? edge_rpc_addr : class_rpc_addr;
        rpc_wdata[0]=hy_mode ? edge_rpc_data : class_rpc_data;
        rpc_rsp_ready[0]=hy_mode ? edge_rpc_rsp_ready : class_rpc_rsp_ready;
        complete_r2=r2_status[141:0]==active_cj && r2_status[146:142]==0 && r2_status[178:147]==0 &&
            r2_status[210:183]==28'd30 && r2_status[182:179]==4'd7;
        // CS中的FS：code[431:429]、IDs[527:432]、输入/输出计数[548:528]/[569:549]。
        if(r2_status[431:429]!=0 || r2_status[527:432]!=active_cj[95:0] ||
           r2_status[548:528]!=21'(P) || r2_status[569:549]!=21'(P) || r2_status[591:570]!=0)complete_r2=0;
        for(integer port_number=0;port_number<8;port_number++)begin
            if(r2_status[211+port_number*21+:21]!=(port_number==7 && !active_cj[141] ? 21'd0 : 21'(P)))complete_r2=0;
        end
        if(r2_status[386:379]!=(active_cj[141] ? 8'hff : 8'h7f))complete_r2=0;
    end
    assign class_rpc_ready=!hy_mode && rpc_ready[0];
    assign edge_rpc_ready=hy_mode && rpc_ready[0];

    generate if(STAGE!=2)begin: with_preprocess
    canny_stream_top #(.W(WIDTH),.H(HEIGHT)) stream(
        .clk(clk),.rst(rst),.cancel(private_abort && !hy_mode),
        .cj_valid(state==START_R2),.cj_ready(r2_cj_ready),.cj(active_cj),
        .in_valid(in_valid && !hy_mode && r2_started && !r2_seen),.in_ready(r2_in_ready),.in_fp(in_fp),
        .class_valid(r2_class_valid),.class_ready(r2_class_ready),.class_payload(r2_class_payload),
        .grad_valid(grad_valid),.grad_ready(grad_ready),.grad_payload(grad_payload),
        .status_valid(r2_status_valid),.status_ready(r2_started && !r2_seen),.status_payload(r2_status));
    class_frame_writer #(.WIDTH(WIDTH),.HEIGHT(HEIGHT),.EXTERNAL_STORAGE(1)) classification_writer(
        .storage_clear(class_storage_clear),.storage_write(class_storage_write),
        .storage_next(class_storage_next),.storage_current(shared_writer_payload),
        .clk(clk),.rst(rst),.cfg_valid(state==CFG_CLASS_REQ),.cfg_ready(class_cfg_ready),.cfg_base(saved_class_base),.cfg_id(active_cj[95:0]),
        .cfg_rsp_valid(class_cfg_rsp_valid),.cfg_rsp_ready(state==CFG_CLASS_WAIT),.cfg_rsp_error(class_cfg_rsp_error),
        .in_valid(r2_class_valid),.in_ready(r2_class_ready),.in_payload(r2_class_payload),.abort_valid(private_abort && !hy_mode),.abort_id(active_cj[95:0]),
        .done_valid(class_done_valid),.done_ready(!class_seen),.done_error(class_done_error),.done_aborted(class_done_aborted),.done_drained(class_done_drained),.count(class_count),
        .line_req_valid(class_rpc_valid),.line_req_ready(class_rpc_ready),.line_write(class_rpc_write),.line_addr(class_rpc_addr),.line_wdata(class_rpc_data),
        .line_rsp_valid(!hy_mode && rpc_rsp_valid[0]),.line_rsp_ready(class_rpc_rsp_ready),.line_rdata(rpc_rdata),.line_error(rpc_error),.line_drained(rpc_drained),.quarantined(class_quarantined));
    end else begin: no_preprocess
        // Explicit elaboration pruning: an unreachable FSM state alone does
        // not make Efinity remove preserved line RAMs and DSP storage cells.
        assign r2_cj_ready=0,r2_in_ready=0,r2_class_valid=0,r2_class_ready=0;
        assign r2_class_payload='0,r2_status_valid=0,r2_status='0;
        assign grad_valid=0,grad_payload='0;
        assign class_cfg_ready=0,class_cfg_rsp_valid=0,class_cfg_rsp_error=0;
        assign class_done_valid=0,class_done_error=0,class_done_aborted=0,class_done_drained=1,class_count=0;
        assign class_rpc_valid=0,class_rpc_write=0,class_rpc_addr=0,class_rpc_data=0,class_rpc_rsp_ready=0;
        assign class_quarantined=0,class_storage_clear=0,class_storage_write=0,class_storage_next=0;
    end endgenerate
    generate if(STAGE!=1)begin: with_trace
    edge_frame_writer #(.WIDTH(WIDTH),.HEIGHT(HEIGHT),.EXTERNAL_STORAGE(1),.LANES(EXPORT_LANES)) result_writer(
        .storage_clear(edge_storage_clear),.storage_write(edge_storage_write),
        .storage_next(edge_storage_next),.storage_current(shared_writer_payload),
        .clk(clk),.rst(rst),.cfg_valid(state==CFG_RESULT_REQ),.cfg_ready(edge_cfg_ready),.cfg_base(saved_result_base),.cfg_id(active_handle),
        .cfg_rsp_valid(edge_cfg_rsp_valid),.cfg_rsp_ready(state==CFG_RESULT_WAIT),.cfg_rsp_error(edge_cfg_rsp_error),
        .in_valid(h_pixel_valid),.in_ready(edge_in_ready),.in_index(h_pixel_index),.in_edge(h_pixel_edge),.in_edges(h_pixel_edges),.in_id(h_pixel_id),
        .abort_valid(private_abort && hy_mode),.abort_id(active_handle),
        .done_valid(edge_done_valid),.done_ready(!edge_seen),.done_error(edge_done_error),.done_aborted(edge_done_aborted),.done_drained(edge_done_drained),.count(edge_count),
        .line_req_valid(edge_rpc_valid),.line_req_ready(edge_rpc_ready),.line_write(edge_rpc_write),.line_addr(edge_rpc_addr),.line_wdata(edge_rpc_data),
        .line_rsp_valid(hy_mode && rpc_rsp_valid[0]),.line_rsp_ready(edge_rpc_rsp_ready),.line_rdata(rpc_rdata),.line_error(rpc_error),.line_drained(rpc_drained),.quarantined(edge_quarantined));
    canny_memory_top #(.WIDTH(WIDTH),.HEIGHT(HEIGHT),.EXPORT_LANES(EXPORT_LANES)) memory_algorithm(
        .clk(clk),.rst(rst),.job_valid(state==START_HY),.job_ready(h_job_ready),.job_id(active_handle),.state_base(saved_class_base),.queue_base(saved_queue_base),
        .cancel_valid(private_abort && hy_mode),.cancel_id(active_handle),
        .pixel_valid(h_pixel_valid),.pixel_ready(h_pixel_ready),.pixel_index(h_pixel_index),.pixel_edge(h_pixel_edge),.pixel_edges(h_pixel_edges),.pixel_job_id(h_pixel_id),
        .done_valid(h_done_valid),.done_ready(hy_started && !hy_seen),.done_job_id(h_done_id),.outcome(h_outcome),.reason(h_reason),
        .enqueue_count(h_enqueue),.pop_count(h_pop),.output_count(h_output),
        .line_req_valid(rpc_valid[1]),.line_req_ready(rpc_ready[1]),.line_write(rpc_write[1]),.line_addr(rpc_addr[1]),.line_wdata(rpc_wdata[1]),
        .line_rsp_valid(rpc_rsp_valid[1]),.line_rsp_ready(rpc_rsp_ready[1]),.line_rdata(rpc_rdata),.line_error(rpc_error),.line_drained(rpc_drained),.quarantined(h_quarantined));
    end else begin: no_trace
        assign edge_cfg_ready=0,edge_cfg_rsp_valid=0,edge_cfg_rsp_error=0,edge_in_ready=0;
        assign edge_done_valid=0,edge_done_error=0,edge_done_aborted=0,edge_done_drained=1,edge_count=0;
        assign edge_rpc_valid=0,edge_rpc_write=0,edge_rpc_addr=0,edge_rpc_data=0,edge_rpc_rsp_ready=0;
        assign edge_quarantined=0,edge_storage_clear=0,edge_storage_write=0,edge_storage_next=0;
        assign h_job_ready=0,h_pixel_valid=0,h_pixel_edge=0,h_pixel_edges=0,h_pixel_index=0,h_pixel_id=0;
        assign h_done_valid=0,h_done_id=0,h_outcome=0,h_reason=0,h_enqueue=0,h_pop=0,h_output=0,h_quarantined=0;
        assign rpc_valid[1]=0,rpc_write[1]=0,rpc_addr[1]=0,rpc_wdata[1]=0,rpc_rsp_ready[1]=0;
    end endgenerate
    line_rpc_arbiter2 external_lines(.clk(clk),.rst(rst),.req_valid(rpc_valid),.req_ready(rpc_ready),.req_write(rpc_write),.req_addr(rpc_addr),.req_data(rpc_wdata),
        .rsp_valid(rpc_rsp_valid),.rsp_ready(rpc_rsp_ready),.rsp_data(rpc_rdata),.rsp_error(rpc_error),.rsp_drained(rpc_drained),
        .line_req_valid(line_req_valid),.line_req_ready(line_req_ready),.line_write(line_write),.line_addr(line_addr),.line_wdata(line_wdata),
        .line_rsp_valid(line_rsp_valid),.line_rsp_ready(line_rsp_ready),.line_rdata(line_rdata),.line_error(line_error),.line_drained(line_drained),.quarantined(a_quarantined));

    always_ff @(posedge clk)begin
        if(rst)begin
            state<=IDLE;active_cj<=0;saved_class_base<=0;saved_queue_base<=0;saved_result_base<=0;next_handle<=0;active_handle<=0;
            hy_mode<=0;cancel_sticky<=0;failure_sticky<=0;failure_mask<=0;
            r2_started<=0;r2_seen<=0;class_seen<=0;hy_started<=0;hy_seen<=0;edge_seen<=0;r2_success<=0;class_success<=0;
            outcome<=0;reason<=0;input_pairs<=0;class_pairs<=0;output_pixels<=0;edge_pixels<=0;r2_status_snapshot<=0;discarded_pixels<=0;
        end else begin
            if(state!=IDLE && state!=DONE)begin
                if(matching_cancel)cancel_sticky<=1;
                if(physical_error)begin failure_sticky<=1;failure_mask[22]<=1;end
                if(r2_status_fire)begin
                    r2_status_snapshot<=r2_status;r2_seen<=1;r2_success<=complete_r2;
                    input_pairs<=r2_status[231:211];class_pairs<=r2_status[357:337];
                    if(!complete_r2 && !(private_abort && (r2_status[178:147]&32'hfffffffd)==0))begin
                        failure_sticky<=1;failure_mask[24]<=1;
                    end
                end
                if(class_done_fire)begin
                    class_seen<=1;class_success<=!class_done_error && class_done_drained && class_count==22'(P);
                    if(class_done_error && !(class_done_aborted && private_abort))begin failure_sticky<=1;failure_mask[21]<=1;end
                end
                if(hy_done_fire)begin
                    hy_seen<=1;edge_pixels<=h_enqueue;
                    if(h_outcome==1 || (h_outcome==2 && !private_abort) || h_done_id!=active_handle ||
                       (h_outcome==0 && (h_pop!=h_enqueue || h_output!=22'(N))))begin failure_sticky<=1;failure_mask[23]<=1;end
                end
                if(edge_done_fire)begin
                    edge_seen<=1;output_pixels<=edge_count;
                    if(edge_done_error && !(edge_done_aborted && private_abort))begin failure_sticky<=1;failure_mask[21]<=1;end
                end
                if(h_pixel_valid && h_pixel_ready && !edge_in_ready)discarded_pixels<=discarded_pixels+h_pixel_step;
            end
            if(!quarantined)case(state)
                IDLE:if(cj_valid && cj_ready)begin
                    active_cj<=cj;saved_class_base<=class_base;saved_queue_base<=queue_base;saved_result_base<=result_base;
                    active_handle<=next_handle+64'd1;next_handle<=next_handle+64'd1;
                    hy_mode<=0;cancel_sticky<=matching_cancel;failure_sticky<=0;failure_mask<=0;
                    r2_started<=0;r2_seen<=0;class_seen<=0;hy_started<=0;hy_seen<=0;edge_seen<=0;r2_success<=0;class_success<=0;
                    outcome<=0;reason<=0;input_pairs<=0;class_pairs<=0;output_pixels<=0;edge_pixels<=0;r2_status_snapshot<=0;discarded_pixels<=0;
                    if(!job_legal)begin outcome<=1;reason<=32'h00100000;state<=DONE;end
                    else if(STAGE==2)begin
                        // Caller owns a successfully drained class frame. The
                        // streaming stage was completed in the other instance.
                        input_pairs<=21'(P);class_pairs<=21'(P);
                        hy_mode<=1;state<=CFG_RESULT_REQ;
                    end else state<=CFG_CLASS_REQ;
                end
                CFG_CLASS_REQ:if(class_cfg_ready)state<=CFG_CLASS_WAIT;
                CFG_CLASS_WAIT:if(class_cfg_rsp_valid)begin
                    if(class_cfg_rsp_error)begin outcome<=1;reason<=32'h00100000;state<=DONE;end else state<=START_R2;
                end
                START_R2:if(r2_cj_ready)begin r2_started<=1;state<=R2_RUN;end
                R2_RUN:if(r2_seen && class_seen)begin
                    if(STAGE==1 || private_abort || !r2_success || !class_success)state<=FINAL;
                    else begin hy_mode<=1;state<=CFG_RESULT_REQ;end
                end
                CFG_RESULT_REQ:if(edge_cfg_ready)state<=CFG_RESULT_WAIT;
                CFG_RESULT_WAIT:if(edge_cfg_rsp_valid)begin
                    if(edge_cfg_rsp_error)begin outcome<=1;reason<=32'h00100000;state<=DONE;end else state<=START_HY;
                end
                START_HY:if(h_job_ready)begin hy_started<=1;state<=HY_RUN;end
                HY_RUN:if(hy_seen && edge_seen)state<=FINAL;
                FINAL:begin
                    if(failure_sticky)begin outcome<=1;reason<=failure_mask;end
                    else if(cancellation)begin outcome<=2;reason<=0;end
                    else if(STAGE==1)begin
                        if(r2_success&&class_success&&input_pairs==21'(P)&&class_pairs==21'(P))begin outcome<=0;reason<=0;end
                        else begin outcome<=1;reason<=32'h01000000;end
                    end
                    else if(!hy_seen || !edge_seen || output_pixels!=22'(N))begin outcome<=1;reason<=32'h01000000;end
                    else begin outcome<=0;reason<=0;end
                    state<=DONE;
                end
                DONE:if(done_ready)state<=IDLE;
                default:begin end
            endcase
        end
    end
endmodule
