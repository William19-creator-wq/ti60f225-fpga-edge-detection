`define sg25 
